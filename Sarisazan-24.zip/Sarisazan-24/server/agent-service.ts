import Fuse from 'fuse.js';
import OpenAI from 'openai';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface Article {
  chapter: string | null;
  article_number: number;
  article_title: string;
  text: string;
}

interface CachedResponse {
  answer: string;
  references: string[];
  source: 'local' | 'api';
  timestamp: number;
}

class AgentService {
  private articles: Article[] = [];
  private fuse: Fuse<Article> | null = null;
  private cache: Map<string, CachedResponse> = new Map();
  private openai: OpenAI | null = null;
  private readonly CACHE_DURATION = 7 * 24 * 60 * 60 * 1000;
  private readonly API_TIMEOUT = 8000;

  async initialize() {
    const jsonlPath = path.join(__dirname, 'assets', 'sharayet_omoomi_peyman_articles_v2.jsonl');
    
    if (!fs.existsSync(jsonlPath)) {
      console.error('❌ JSONL knowledge base not found at:', jsonlPath);
      return;
    }

    const content = fs.readFileSync(jsonlPath, 'utf-8');
    const lines = content.trim().split('\n');
    
    this.articles = lines.map(line => JSON.parse(line) as Article);
    
    this.fuse = new Fuse(this.articles, {
      keys: [
        { name: 'article_title', weight: 0.4 },
        { name: 'text', weight: 0.6 }
      ],
      threshold: 0.4,
      includeScore: true,
      minMatchCharLength: 3
    });

    const apiKey = process.env.OPENAI_API_KEY;
    if (apiKey) {
      this.openai = new OpenAI({ apiKey });
    }

    console.log(`✅ Agent initialized with ${this.articles.length} articles`);
    if (this.openai) {
      console.log('✅ OpenAI API connected');
    } else {
      console.log('⚠️  OpenAI API key not set - agent will work in local-only mode');
    }
  }

  normalizeQuery(query: string): string {
    return query
      .replace(/[؟،؛]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  searchLocal(query: string): { articles: Article[]; score: number } {
    if (!this.fuse) {
      return { articles: [], score: 0 };
    }

    const normalized = this.normalizeQuery(query);
    const results = this.fuse.search(normalized);

    if (results.length === 0) {
      return { articles: [], score: 0 };
    }

    const topResults = results.slice(0, 3);
    const avgScore = topResults.reduce((sum, r) => sum + (1 - (r.score || 1)), 0) / topResults.length;

    return {
      articles: topResults.map(r => r.item),
      score: avgScore
    };
  }

  canAnswerLocally(query: string, searchResults: { articles: Article[]; score: number }): boolean {
    if (searchResults.articles.length === 0) return false;
    
    const lowerQuery = query.toLowerCase();
    
    const simpleQuestions = [
      'چند روز', 'چه مدت', 'چقدر', 'کی', 'کجا',
      'مهلت', 'تعریف', 'چیست', 'چیه', 'یعنی',
      'منظور از', 'تفاوت', 'فرق'
    ];

    const isSimpleQuestion = simpleQuestions.some(keyword => lowerQuery.includes(keyword));
    
    if (isSimpleQuestion && searchResults.score > 0.5) {
      return true;
    }

    if (searchResults.score > 0.7) {
      return true;
    }

    return false;
  }

  generateLocalAnswer(query: string, articles: Article[]): { answer: string; references: string[] } {
    const references = articles.map(a => `ماده ${a.article_number}`);
    
    let answer = '';
    
    if (articles.length === 1) {
      const art = articles[0];
      answer = `طبق ماده ${art.article_number} (${art.article_title}):\n\n${art.text}`;
    } else {
      answer = 'بر اساس شرایط عمومی پیمان:\n\n';
      articles.forEach(art => {
        answer += `📌 ماده ${art.article_number} - ${art.article_title}:\n${art.text}\n\n`;
      });
    }

    return { answer, references };
  }

  async askAPI(query: string, articles: Article[]): Promise<{ answer: string; references: string[] }> {
    if (!this.openai) {
      throw new Error('OpenAI API not configured');
    }

    const context = articles.map(a => 
      `ماده ${a.article_number} - ${a.article_title}:\n${a.text}`
    ).join('\n\n');

    const systemPrompt = `تو یک مشاور حقوقی متخصص در شرایط عمومی پیمان‌های ساختمانی ایران هستی.
به سؤالات کاربران بر اساس مواد قانونی ارائه شده پاسخ بده.
پاسخ‌هایت باید:
- دقیق و مستند باشند
- به زبان فارسی رسمی و روان باشند
- حداکثر 300 کلمه داشته باشند
- مستقیماً به سؤال پاسخ دهند
- از مواد قانونی ارائه شده استناد کنند`;

    const userPrompt = `مواد مرتبط:
${context}

سؤال: ${query}

لطفاً بر اساس مواد بالا، پاسخ دقیق و مستند ارائه کن.`;

    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), this.API_TIMEOUT);

      const completion = await this.openai.chat.completions.create({
        model: 'gpt-4-turbo-preview',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        temperature: 0.2,
        max_tokens: 300
      }, { signal: controller.signal as any });

      clearTimeout(timeout);

      const answer = completion.choices[0]?.message?.content || 'متأسفانه نتوانستم پاسخ مناسبی تولید کنم.';
      const references = articles.map(a => `ماده ${a.article_number}`);

      return { answer, references };
    } catch (error: any) {
      if (error.name === 'AbortError') {
        throw new Error('درخواست به دلیل طولانی شدن متوقف شد. لطفاً دوباره تلاش کنید.');
      }
      throw error;
    }
  }

  async ask(query: string): Promise<{ answer: string; references: string[]; source: 'local' | 'api' }> {
    const cacheKey = this.normalizeQuery(query);
    
    const cached = this.cache.get(cacheKey);
    if (cached && (Date.now() - cached.timestamp) < this.CACHE_DURATION) {
      console.log('✅ Returning cached response');
      return {
        answer: cached.answer,
        references: cached.references,
        source: cached.source
      };
    }

    const searchResults = this.searchLocal(query);

    if (this.canAnswerLocally(query, searchResults)) {
      console.log('✅ Answering from local knowledge base');
      const { answer, references } = this.generateLocalAnswer(query, searchResults.articles);
      
      const response = { answer, references, source: 'local' as const };
      this.cache.set(cacheKey, { ...response, timestamp: Date.now() });
      
      return response;
    }

    if (searchResults.articles.length > 0 && this.openai) {
      console.log('🤖 Using OpenAI API for deeper analysis');
      try {
        const { answer, references } = await this.askAPI(query, searchResults.articles.slice(0, 3));
        
        const response = { answer, references, source: 'api' as const };
        this.cache.set(cacheKey, { ...response, timestamp: Date.now() });
        
        return response;
      } catch (error) {
        console.error('❌ OpenAI API error:', error);
        const { answer, references } = this.generateLocalAnswer(query, searchResults.articles);
        return { answer, references, source: 'local' };
      }
    }

    if (searchResults.articles.length > 0) {
      console.log('✅ Answering from local knowledge base (API not available)');
      const { answer, references } = this.generateLocalAnswer(query, searchResults.articles);
      return { answer, references, source: 'local' };
    }

    return {
      answer: 'متأسفانه در شرایط عمومی پیمان، اطلاعات مرتبط با سؤال شما پیدا نشد. لطفاً سؤال خود را با جزئیات بیشتری مطرح کنید.',
      references: [],
      source: 'local'
    };
  }

  getArticle(articleNumber: number): Article | null {
    return this.articles.find(a => a.article_number === articleNumber) || null;
  }

  isConfigured(): boolean {
    return this.openai !== null;
  }

  clearExpiredCache() {
    const now = Date.now();
    const entries = Array.from(this.cache.entries());
    for (const [key, value] of entries) {
      if (now - value.timestamp > this.CACHE_DURATION) {
        this.cache.delete(key);
      }
    }
  }
}

export const agentService = new AgentService();
