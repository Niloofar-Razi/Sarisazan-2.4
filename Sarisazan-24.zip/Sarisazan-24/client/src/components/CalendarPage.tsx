import { PageHeader } from "./PageHeader";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Textarea } from "./ui/textarea";
import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, Bell, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { toJalaali, toGregorian } from "jalaali-js";

interface CalendarNote {
  id: string;
  userId: string;
  date: string;
  content: string;
}

interface Task {
  id: string;
  title: string;
  reminderDateTime: string;
}

const PERSIAN_MONTHS = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
];

const PERSIAN_WEEKDAYS = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];

export default function CalendarPage() {
  const today = new Date();
  const todayJalali = toJalaali(today);
  
  const [currentYear, setCurrentYear] = useState(todayJalali.jy);
  const [currentMonth, setCurrentMonth] = useState(todayJalali.jm);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [noteContent, setNoteContent] = useState('');
  const [notes, setNotes] = useState<CalendarNote[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const { toast } = useToast();

  const currentUser = JSON.parse(localStorage.getItem("user") || '{"id":"1"}');

  useEffect(() => {
    fetchNotes();
    fetchTasksWithReminders();
  }, [currentYear, currentMonth]);

  useEffect(() => {
    if (selectedDate) {
      const note = notes.find(n => n.date === selectedDate);
      setNoteContent(note?.content || '');
    }
  }, [selectedDate, notes]);

  const fetchNotes = async () => {
    try {
      const response = await fetch(`/api/calendar-notes?userId=${currentUser.id}`);
      if (response.ok) {
        const data = await response.json();
        setNotes(data);
      }
    } catch (error) {
      console.error('Error fetching notes:', error);
    }
  };

  const fetchTasksWithReminders = async () => {
    try {
      const response = await fetch('/api/tasks');
      if (response.ok) {
        const data = await response.json();
        const tasksWithReminders = data.filter((t: Task) => t.reminderDateTime);
        setTasks(tasksWithReminders);
      }
    } catch (error) {
      console.error('Error fetching tasks:', error);
    }
  };

  const handleSaveNote = async () => {
    if (!selectedDate) return;

    try {
      const response = await fetch('/api/calendar-notes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          date: selectedDate,
          content: noteContent,
        }),
      });

      if (response.ok) {
        toast({
          title: "✅ یادداشت ذخیره شد",
          description: "یادداشت با موفقیت ذخیره شد",
        });
        fetchNotes();
      }
    } catch (error) {
      console.error('Error saving note:', error);
      toast({
        title: "❌ خطا",
        description: "ذخیره یادداشت با خطا مواجه شد",
        variant: "destructive",
      });
    }
  };

  const getDaysInJalaliMonth = (year: number, month: number) => {
    if (month <= 6) return 31;
    if (month <= 11) return 30;
    
    // Check for leap year in Esfand (month 12)
    // Use safe calculation: if year+1/1/1 minus year/12/29 is 2 days, it's a leap year
    try {
      const lastDayOfYear = toGregorian(year, 12, 29);
      const firstDayNextYear = toGregorian(year + 1, 1, 1);
      const lastDay = new Date(lastDayOfYear.gy, lastDayOfYear.gm - 1, lastDayOfYear.gd);
      const firstDay = new Date(firstDayNextYear.gy, firstDayNextYear.gm - 1, firstDayNextYear.gd);
      const diffDays = Math.round((firstDay.getTime() - lastDay.getTime()) / (1000 * 60 * 60 * 24));
      return diffDays === 2 ? 30 : 29;
    } catch {
      return 29; // Default to 29 if conversion fails
    }
  };

  const getFirstDayOfMonth = (year: number, month: number) => {
    const gregorian = toGregorian(year, month, 1);
    const date = new Date(gregorian.gy, gregorian.gm - 1, gregorian.gd);
    return (date.getDay() + 1) % 7; // Convert to Jalali week (Saturday = 0)
  };

  const renderCalendar = () => {
    const daysInMonth = getDaysInJalaliMonth(currentYear, currentMonth);
    const firstDay = getFirstDayOfMonth(currentYear, currentMonth);
    const days = [];

    // Add empty cells for days before the first day
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="aspect-square"></div>);
    }

    // Add day cells
    for (let day = 1; day <= daysInMonth; day++) {
      const dateString = `${currentYear}-${String(currentMonth).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const isToday = day === todayJalali.jd && currentMonth === todayJalali.jm && currentYear === todayJalali.jy;
      const isSelected = selectedDate === dateString;
      const hasNote = notes.some(n => n.date === dateString);
      
      // Check if there are tasks with reminders on this day
      const gregorian = toGregorian(currentYear, currentMonth, day);
      const gregorianDate = new Date(gregorian.gy, gregorian.gm - 1, gregorian.gd);
      const tasksOnDay = tasks.filter(t => {
        const reminderDate = new Date(t.reminderDateTime);
        return reminderDate.toDateString() === gregorianDate.toDateString();
      });

      days.push(
        <div
          key={day}
          onClick={() => setSelectedDate(dateString)}
          className={`
            aspect-square p-2 border rounded-lg cursor-pointer transition-all
            ${isToday ? 'bg-primary text-primary-foreground font-bold' : ''}
            ${isSelected ? 'ring-2 ring-primary' : ''}
            ${!isToday && !isSelected ? 'hover:bg-accent' : ''}
          `}
        >
          <div className="flex flex-col h-full">
            <span className="text-sm">{day}</span>
            <div className="flex-1 flex items-end gap-1">
              {hasNote && (
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              )}
              {tasksOnDay.length > 0 && (
                <Badge variant="destructive" className="text-xs px-1 py-0 h-4">
                  <Bell className="w-2 h-2 ml-0.5" />
                  {tasksOnDay.length}
                </Badge>
              )}
            </div>
          </div>
        </div>
      );
    }

    return days;
  };

  const goToPreviousMonth = () => {
    if (currentMonth === 1) {
      setCurrentMonth(12);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
  };

  const goToNextMonth = () => {
    if (currentMonth === 12) {
      setCurrentMonth(1);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
  };

  const goToToday = () => {
    const today = toJalaali(new Date());
    setCurrentYear(today.jy);
    setCurrentMonth(today.jm);
    setSelectedDate(`${today.jy}-${String(today.jm).padStart(2, '0')}-${String(today.jd).padStart(2, '0')}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title="تقویم"
        subtitle="مدیریت رویدادها و یادآورها"
        theme="calendar"
        actions={
          <Button onClick={goToToday} variant="outline">
            امروز
          </Button>
        }
      />

      <div className="container mx-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2 p-6">
            <div className="space-y-4">
              {/* Calendar Header */}
              <div className="flex items-center justify-between">
                <Button variant="ghost" size="icon" onClick={goToNextMonth}>
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <h3 className="text-lg font-semibold">
                  {PERSIAN_MONTHS[currentMonth - 1]} {currentYear}
                </h3>
                <Button variant="ghost" size="icon" onClick={goToPreviousMonth}>
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>

              {/* Weekday Headers */}
              <div className="grid grid-cols-7 gap-2">
                {PERSIAN_WEEKDAYS.map(day => (
                  <div key={day} className="text-center text-sm font-medium text-muted-foreground p-2">
                    {day}
                  </div>
                ))}
              </div>

              {/* Calendar Days */}
              <div className="grid grid-cols-7 gap-2">
                {renderCalendar()}
              </div>

              {/* Legend */}
              <div className="flex items-center gap-4 pt-4 border-t text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-primary rounded"></div>
                  <span>امروز</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                  <span>یادداشت</span>
                </div>
                <div className="flex items-center gap-2">
                  <Bell className="w-3 h-3 text-destructive" />
                  <span>یادآور وظیفه</span>
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">یادداشت روز</h3>
            {selectedDate ? (
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  {selectedDate}
                </p>
                <Textarea
                  value={noteContent}
                  onChange={(e) => setNoteContent(e.target.value)}
                  placeholder="یادداشت خود را اینجا بنویسید..."
                  rows={8}
                />
                <Button onClick={handleSaveNote} className="w-full gap-2">
                  <Save className="w-4 h-4" />
                  ذخیره یادداشت
                </Button>

                {/* Show tasks with reminders on selected day */}
                {(() => {
                  const parts = selectedDate.split('-').map(Number);
                  const gregorian = toGregorian(parts[0], parts[1], parts[2]);
                  const gregorianDate = new Date(gregorian.gy, gregorian.gm - 1, gregorian.gd);
                  const tasksOnDay = tasks.filter(t => {
                    const reminderDate = new Date(t.reminderDateTime);
                    return reminderDate.toDateString() === gregorianDate.toDateString();
                  });

                  if (tasksOnDay.length > 0) {
                    return (
                      <div className="pt-4 border-t">
                        <h4 className="font-medium mb-2 flex items-center gap-2">
                          <Bell className="w-4 h-4" />
                          یادآورهای این روز
                        </h4>
                        <div className="space-y-2">
                          {tasksOnDay.map(task => (
                            <div key={task.id} className="text-sm p-2 bg-muted rounded">
                              {task.title}
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  }
                  return null;
                })()}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-8">
                یک روز را از تقویم انتخاب کنید
              </p>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
