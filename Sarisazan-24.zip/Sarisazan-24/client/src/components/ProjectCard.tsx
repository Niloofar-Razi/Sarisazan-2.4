import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Calendar, DollarSign, MapPin, ArrowLeft, ListTodo, Plus } from "lucide-react";
import { useState, useEffect } from "react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { FileText } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { toPersianDigits, formatCurrency } from "@/lib/persian-utils";

interface ProjectCardProps {
  id: string;
  title: string;
  contractNumber: string | null;
  location: string | null;
  employer: string | null;
  amount: string | null;
  progress: number | null;
  status: string | null;
  startDate: string | null;
  onViewDetails?: (id: string) => void;
}

interface TaskStats {
  total: number;
  completed: number;
  pending: number;
}

const statusLabels: Record<string, string> = {
  active: "در حال اجرا",
  completed: "تکمیل شده",
  pending: "در انتظار",
  suspended: "متوقف شده",
};

const statusVariants: Record<string, "default" | "outline" | "destructive"> = {
  active: "default" as const,
  completed: "default" as const,
  pending: "outline" as const,
  suspended: "destructive" as const,
};

export default function ProjectCard({
  id,
  title,
  contractNumber,
  location,
  employer,
  amount,
  progress,
  status,
  startDate,
  onViewDetails,
}: ProjectCardProps) {
  const [taskStats, setTaskStats] = useState<TaskStats | null>(null);
  const [loadingTasks, setLoadingTasks] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [users, setUsers] = useState<any[]>([]);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    priority: 'medium',
    reminderDateTime: '',
    assigneeId: '',
    requiresConfirmation: false,
  });

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await fetch('/api/users');
        if (response.ok) {
          const data = await response.json();
          setUsers(data);
        }
      } catch (error) {
        console.error('Error fetching users:', error);
      }
    };
    fetchUsers();
  }, []);

  const fetchProjectTasks = async () => {
    setLoadingTasks(true);
    try {
      const response = await fetch(`/api/tasks/by-project/${id}`);
      if (response.ok) {
        const data = await response.json();
        setTaskStats(data.stats);
      }
    } catch (error) {
      console.error('Error fetching project tasks:', error);
    } finally {
      setLoadingTasks(false);
    }
  };

  const handleCreateTask = async () => {
    try {
      const userId = JSON.parse(localStorage.getItem("user") || '{"id":"1"}').id;

      if (selectedFile) {
        const formDataObj = new FormData();
        formDataObj.append('file', selectedFile);
        formDataObj.append('taskData', JSON.stringify({
          userId,
          ...formData,
          projectId: id,
        }));

        const response = await fetch('/api/tasks/with-attachment', {
          method: 'POST',
          body: formDataObj,
        });

        if (response.ok) {
          toast({
            title: "✅ وظیفه ایجاد شد",
            description: "وظیفه جدید با موفقیت به پروژه اضافه شد",
          });
          resetForm();
          fetchProjectTasks();
        }
      } else {
        const response = await fetch('/api/tasks', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId, ...formData, projectId: id }),
        });

        if (response.ok) {
          toast({
            title: "✅ وظیفه ایجاد شد",
            description: "وظیفه جدید با موفقیت به پروژه اضافه شد",
          });
          resetForm();
          fetchProjectTasks();
        }
      }
    } catch (error) {
      console.error('Error creating task:', error);
      toast({
        title: "❌ خطا",
        description: "ایجاد وظیفه با خطا مواجه شد",
        variant: "destructive",
      });
    }
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      priority: 'medium',
      reminderDateTime: '',
      assigneeId: '',
      requiresConfirmation: false,
    });
    setSelectedFile(null);
    setDialogOpen(false);
  };

  const completionPercentage = taskStats && taskStats.total > 0
    ? Math.round((taskStats.completed / taskStats.total) * 100)
    : 0;

  return (
    <Card className="hover-elevate transition-all">
      <CardHeader className="gap-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-lg truncate" data-testid={`project-title-${id}`}>{title}</h3>
            <p className="text-sm text-muted-foreground">شماره قرارداد: {contractNumber ? toPersianDigits(contractNumber) : "نامشخص"}</p>
          </div>
          <div className="flex gap-2">
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="default" size="sm" className="gap-1">
                  <Plus className="w-4 h-4" />
                  وظیفه من
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>ایجاد وظیفه برای: {title}</DialogTitle>
                </DialogHeader>
                
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">عنوان وظیفه *</Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      placeholder="عنوان وظیفه را وارد کنید"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">توضیحات</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      placeholder="توضیحات وظیفه را وارد کنید"
                      rows={4}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="priority">اولویت</Label>
                      <Select
                        value={formData.priority}
                        onValueChange={(value) => setFormData({ ...formData, priority: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">کم</SelectItem>
                          <SelectItem value="medium">متوسط</SelectItem>
                          <SelectItem value="high">زیاد</SelectItem>
                          <SelectItem value="urgent">فوری</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="reminder">یادآوری</Label>
                      <Input
                        id="reminder"
                        type="text"
                        value={formData.reminderDateTime}
                        onChange={(e) => setFormData({ ...formData, reminderDateTime: e.target.value })}
                        placeholder="1403/07/15 14:30"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="assignee">اختصاص به</Label>
                    <Select
                      value={formData.assigneeId}
                      onValueChange={(value) => setFormData({ ...formData, assigneeId: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="انتخاب کاربر (پیش‌فرض: خودم)" />
                      </SelectTrigger>
                      <SelectContent>
                        {users.map(user => (
                          <SelectItem key={user.id} value={user.id}>
                            {user.firstName && user.lastName 
                              ? `${user.firstName} ${user.lastName}`
                              : user.username}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="attachment">پیوست فایل</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        id="attachment"
                        type="file"
                        onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                        className="flex-1"
                      />
                      {selectedFile && (
                        <Badge variant="outline" className="gap-1">
                          <FileText className="h-3 w-3" />
                          {selectedFile.name}
                        </Badge>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="confirmation"
                      checked={formData.requiresConfirmation}
                      onCheckedChange={(checked) => 
                        setFormData({ ...formData, requiresConfirmation: checked as boolean })
                      }
                    />
                    <Label htmlFor="confirmation" className="cursor-pointer">
                      نیاز به تأیید دارد
                    </Label>
                  </div>

                  <div className="flex justify-end gap-2 pt-4">
                    <Button variant="outline" onClick={() => setDialogOpen(false)}>
                      لغو
                    </Button>
                    <Button onClick={handleCreateTask} disabled={!formData.title}>
                      ایجاد وظیفه
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
            <Popover>
              <PopoverTrigger asChild>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="gap-1"
                  onClick={fetchProjectTasks}
                >
                  <ListTodo className="w-4 h-4" />
                  وظایف
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80">
                {loadingTasks ? (
                  <div className="text-center py-4 text-sm text-muted-foreground">
                    در حال بارگذاری...
                  </div>
                ) : taskStats ? (
                  <div className="space-y-4">
                    <div className="text-sm font-medium">مهم‌ترین وظیفه‌های این پروژه</div>
                    
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-sm">
                        <span>کل وظایف</span>
                        <Badge variant="outline">{toPersianDigits(taskStats.total)}</Badge>
                      </div>
                      
                      <div>
                        <div className="flex items-center justify-between text-sm mb-1">
                          <span className="text-green-600">انجام شده</span>
                          <span className="text-green-600 font-medium">{toPersianDigits(taskStats.completed)}</span>
                        </div>
                        <Progress value={taskStats.total > 0 ? (taskStats.completed / taskStats.total) * 100 : 0} className="h-2" />
                      </div>
                      
                      <div>
                        <div className="flex items-center justify-between text-sm mb-1">
                          <span className="text-orange-600">در انتظار</span>
                          <span className="text-orange-600 font-medium">{toPersianDigits(taskStats.pending)}</span>
                        </div>
                        <Progress value={taskStats.total > 0 ? (taskStats.pending / taskStats.total) * 100 : 0} className="h-2" />
                      </div>

                      <div className="pt-2 border-t">
                        <div className="flex items-center justify-between text-sm">
                          <span className="font-medium">درصد تکمیل</span>
                          <span className="font-bold text-primary">{toPersianDigits(completionPercentage)}%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-4 text-sm text-muted-foreground">
                    وظیفه‌ای برای این پروژه وجود ندارد
                  </div>
                )}
              </PopoverContent>
            </Popover>
            <Badge variant={statusVariants[status || "active"]} data-testid={`project-status-${id}`}>
              {statusLabels[status || "active"]}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          {location && (
            <div className="flex items-center gap-2 text-sm">
              <MapPin className="w-4 h-4 text-muted-foreground" />
              <span>{location}</span>
            </div>
          )}
          {amount && (
            <div className="flex items-center gap-2 text-sm">
              <DollarSign className="w-4 h-4 text-muted-foreground" />
              <span>{formatCurrency(amount)} ریال</span>
            </div>
          )}
          {startDate && (
            <div className="flex items-center gap-2 text-sm">
              <Calendar className="w-4 h-4 text-muted-foreground" />
              <span>شروع: {toPersianDigits(startDate)}</span>
            </div>
          )}
        </div>
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">پیشرفت ریالی</span>
            <span className="font-medium">{toPersianDigits(progress ?? 0)}%</span>
          </div>
          <Progress value={progress ?? 0} className="h-2" />
        </div>
        {employer && <p className="text-sm text-muted-foreground">کارفرما: {employer}</p>}
      </CardContent>
      <CardFooter>
        <Button 
          variant="outline" 
          className="w-full" 
          onClick={() => onViewDetails?.(id)}
          data-testid={`button-view-project-${id}`}
        >
          مشاهده جزئیات
          <ArrowLeft className="w-4 h-4 mr-2" />
        </Button>
      </CardFooter>
    </Card>
  );
}
