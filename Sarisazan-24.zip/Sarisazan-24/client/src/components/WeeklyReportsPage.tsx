import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, FileText, Trash2, Send } from "lucide-react";
import { format } from "date-fns-jalali";
import { toPersianDigits } from "@/lib/persian-utils";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface Project {
  id: string;
  title: string;
  contractNumber: string;
}

interface WeeklyReport {
  id: string;
  projectId: string;
  weekStartDate: string;
  weekEndDate: string;
  activities: string;
  notes: string;
  status: string;
  createdBy: string;
  referredTo: string | null;
  referredAt: string | null;
  createdAt: string;
}

interface User {
  id: string;
  firstName: string;
  lastName: string;
  username: string;
}

export default function WeeklyReportsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [currentDate] = useState(new Date());
  const [selectedProject, setSelectedProject] = useState("");
  const [weekStartDate, setWeekStartDate] = useState(format(new Date(), 'yyyy/MM/dd'));
  const [weekEndDate, setWeekEndDate] = useState(format(new Date(), 'yyyy/MM/dd'));
  const [activities, setActivities] = useState<string[]>([""]);
  const [notes, setNotes] = useState("");
  const [isReferDialogOpen, setIsReferDialogOpen] = useState(false);
  const [selectedReport, setSelectedReport] = useState<WeeklyReport | null>(null);
  const [referToUser, setReferToUser] = useState("");

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const response = await fetch("/api/projects");
      if (!response.ok) throw new Error("خطا در دریافت پروژه‌ها");
      return response.json();
    },
  });

  const { data: users = [] } = useQuery<User[]>({
    queryKey: ["/api/users"],
    queryFn: async () => {
      const response = await fetch("/api/users");
      if (!response.ok) throw new Error("خطا در دریافت کاربران");
      return response.json();
    },
  });

  const { data: reports = [] } = useQuery<WeeklyReport[]>({
    queryKey: ["/api/weekly-reports"],
    queryFn: async () => {
      const response = await fetch("/api/weekly-reports");
      if (!response.ok) throw new Error("خطا در دریافت گزارش‌ها");
      return response.json();
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch("/api/weekly-reports", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("خطا در ثبت گزارش");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/weekly-reports"] });
      resetForm();
      toast({ title: "گزارش هفتگی با موفقیت ثبت شد و به مدیر پروژه ارسال شد" });
    },
  });

  const referMutation = useMutation({
    mutationFn: async ({ id, referredTo }: { id: string; referredTo: string }) => {
      const response = await fetch(`/api/weekly-reports/${id}/refer`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ referredTo }),
      });
      if (!response.ok) throw new Error("خطا در ارجاع گزارش");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/weekly-reports"] });
      setIsReferDialogOpen(false);
      setSelectedReport(null);
      setReferToUser("");
      toast({ title: "گزارش با موفقیت ارجاع داده شد" });
    },
  });

  const resetForm = () => {
    setSelectedProject("");
    setWeekStartDate(format(new Date(), 'yyyy/MM/dd'));
    setWeekEndDate(format(new Date(), 'yyyy/MM/dd'));
    setActivities([""]);
    setNotes("");
  };

  const handleAddActivity = () => {
    setActivities([...activities, ""]);
  };

  const handleRemoveActivity = (index: number) => {
    if (activities.length > 1) {
      setActivities(activities.filter((_, i) => i !== index));
    }
  };

  const handleActivityChange = (index: number, value: string) => {
    const newActivities = [...activities];
    newActivities[index] = value;
    setActivities(newActivities);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject) {
      toast({ title: "لطفاً پروژه را انتخاب کنید", variant: "destructive" });
      return;
    }
    
    const filteredActivities = activities.filter(a => a.trim() !== "");
    if (filteredActivities.length === 0) {
      toast({ title: "لطفاً حداقل یک فعالیت وارد کنید", variant: "destructive" });
      return;
    }

    createMutation.mutate({
      projectId: selectedProject,
      weekStartDate,
      weekEndDate,
      activities: JSON.stringify(filteredActivities),
      notes,
    });
  };

  const handleRefer = () => {
    if (selectedReport && referToUser) {
      referMutation.mutate({ id: selectedReport.id, referredTo: referToUser });
    }
  };

  const getProjectTitle = (projectId: string) => {
    const project = projects.find(p => p.id === projectId);
    return project?.title || "-";
  };

  const getUserName = (userId: string | null) => {
    if (!userId) return "-";
    const user = users.find(u => u.id === userId);
    return user ? `${user.firstName || ""} ${user.lastName || ""}`.trim() || user.username : "-";
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">گزارش هفتگی دفتر فنی</h1>
        <p className="text-muted-foreground">ثبت و مدیریت گزارش‌های هفتگی دفتر فنی</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            فرم گزارش هفتگی دفتر فنی
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="project">پروژه *</Label>
                <Select value={selectedProject} onValueChange={setSelectedProject}>
                  <SelectTrigger id="project">
                    <SelectValue placeholder="انتخاب پروژه" />
                  </SelectTrigger>
                  <SelectContent>
                    {projects.map((project) => (
                      <SelectItem key={project.id} value={project.id}>
                        {project.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="week-start">تاریخ شروع هفته</Label>
                <Input 
                  id="week-start" 
                  type="text" 
                  value={weekStartDate}
                  onChange={(e) => setWeekStartDate(e.target.value)}
                  placeholder="1403/07/15" 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="week-end">تاریخ پایان هفته</Label>
                <Input 
                  id="week-end" 
                  type="text" 
                  value={weekEndDate}
                  onChange={(e) => setWeekEndDate(e.target.value)}
                  placeholder="1403/07/21" 
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>شرح فعالیت‌های فنی *</Label>
                <Button type="button" variant="outline" size="sm" onClick={handleAddActivity}>
                  <Plus className="w-4 h-4 ml-2" />
                  افزودن فعالیت
                </Button>
              </div>
              <div className="space-y-2">
                {activities.map((activity, index) => (
                  <div key={index} className="flex gap-2">
                    <Input
                      value={activity}
                      onChange={(e) => handleActivityChange(index, e.target.value)}
                      placeholder={`فعالیت ${toPersianDigits(index + 1)}`}
                    />
                    {activities.length > 1 && (
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={() => handleRemoveActivity(index)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">یادداشت‌ها</Label>
              <Textarea 
                id="notes" 
                placeholder="یادداشت‌های اضافی..." 
                rows={3}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </div>

            <div className="flex justify-end">
              <Button type="submit" disabled={createMutation.isPending}>
                <Send className="w-4 h-4 ml-2" />
                ثبت و ارسال گزارش
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>گزارش‌های ثبت شده</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>پروژه</TableHead>
                <TableHead>تاریخ شروع</TableHead>
                <TableHead>تاریخ پایان</TableHead>
                <TableHead>وضعیت</TableHead>
                <TableHead>ارجاع شده به</TableHead>
                <TableHead>تاریخ ثبت</TableHead>
                <TableHead>عملیات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {reports.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center text-muted-foreground">
                    گزارشی ثبت نشده است
                  </TableCell>
                </TableRow>
              ) : (
                reports.map((report) => (
                  <TableRow key={report.id}>
                    <TableCell>{getProjectTitle(report.projectId)}</TableCell>
                    <TableCell>{toPersianDigits(report.weekStartDate)}</TableCell>
                    <TableCell>{toPersianDigits(report.weekEndDate)}</TableCell>
                    <TableCell>{report.status}</TableCell>
                    <TableCell>{getUserName(report.referredTo)}</TableCell>
                    <TableCell>
                      {toPersianDigits(format(new Date(report.createdAt), 'yyyy/MM/dd HH:mm'))}
                    </TableCell>
                    <TableCell>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setSelectedReport(report);
                          setIsReferDialogOpen(true);
                        }}
                      >
                        ارجاع
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={isReferDialogOpen} onOpenChange={setIsReferDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>ارجاع گزارش</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>ارجاع به</Label>
              <Select value={referToUser} onValueChange={setReferToUser}>
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب کاربر" />
                </SelectTrigger>
                <SelectContent>
                  {users.map((user) => (
                    <SelectItem key={user.id} value={user.id}>
                      {`${user.firstName || ""} ${user.lastName || ""}`.trim() || user.username}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsReferDialogOpen(false)}>
                انصراف
              </Button>
              <Button onClick={handleRefer} disabled={!referToUser || referMutation.isPending}>
                ارجاع
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
