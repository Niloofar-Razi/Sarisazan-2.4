import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MessageSquare, Plus, Send, Paperclip, Search, Users, User, FolderOpen } from "lucide-react";
import { format } from "date-fns-jalali";
import { useProject } from "@/lib/project-context";
import type { Conversation, Message, User as UserType, Project } from "@shared/schema";

export default function MessagesPage() {
  const { selectedProject } = useProject();
  const queryClient = useQueryClient();
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
  const [messageContent, setMessageContent] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFiles, setSelectedFiles] = useState<FileList | null>(null);
  const [newConversation, setNewConversation] = useState({
    type: "direct",
    title: "",
    memberIds: [] as string[],
    projectId: "",
  });

  const { data: users = [] } = useQuery<UserType[]>({
    queryKey: ["/api/users"],
  });

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const { data: conversations = [] } = useQuery<Conversation[]>({
    queryKey: ["/api/conversations"],
  });

  const { data: messages = [] } = useQuery<(Message & { files?: any[], reads?: any[] })[]>({
    queryKey: [`/api/conversations/${selectedConversation}/messages`],
    enabled: !!selectedConversation,
  });

  const createConversationMutation = useMutation({
    mutationFn: async (data: typeof newConversation) => {
      const res = await fetch("/api/conversations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      setNewConversation({ type: "direct", title: "", memberIds: [], projectId: "" });
    },
  });

  const sendMessageMutation = useMutation({
    mutationFn: async ({ conversationId, content, files }: { conversationId: string, content: string, files?: FileList }) => {
      const formData = new FormData();
      formData.append("senderId", "current-user-id");
      formData.append("content", content);
      
      if (files) {
        for (let i = 0; i < files.length; i++) {
          formData.append("files", files[i]);
        }
      }

      const res = await fetch(`/api/conversations/${conversationId}/messages`, {
        method: "POST",
        body: formData,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/conversations/${selectedConversation}/messages`] });
      setMessageContent("");
      setSelectedFiles(null);
    },
  });

  const handleSendMessage = () => {
    if (selectedConversation && (messageContent.trim() || selectedFiles)) {
      sendMessageMutation.mutate({
        conversationId: selectedConversation,
        content: messageContent,
        files: selectedFiles || undefined,
      });
    }
  };

  const getConversationIcon = (type: string) => {
    switch (type) {
      case "direct": return <User className="h-4 w-4" />;
      case "group": return <Users className="h-4 w-4" />;
      case "project": return <FolderOpen className="h-4 w-4" />;
      default: return <MessageSquare className="h-4 w-4" />;
    }
  };

  const getConversationTypeLabel = (type: string) => {
    switch (type) {
      case "direct": return "مستقیم";
      case "group": return "گروهی";
      case "project": return "پروژه‌ای";
      default: return type;
    }
  };

  return (
    <div className="container mx-auto p-6 max-w-7xl" dir="rtl">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">پیام‌ها</h1>
          <p className="text-muted-foreground">مدیریت گفتگوها و پیام‌های داخلی</p>
        </div>
        
        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 ml-2" />
              گفتگوی جدید
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>ایجاد گفتگوی جدید</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>نوع گفتگو</Label>
                <Select value={newConversation.type} onValueChange={(value) => setNewConversation({ ...newConversation, type: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="direct">مستقیم (کاربر به کاربر)</SelectItem>
                    <SelectItem value="group">گروهی</SelectItem>
                    <SelectItem value="project">پروژه‌ای</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>عنوان گفتگو</Label>
                <Input
                  value={newConversation.title}
                  onChange={(e) => setNewConversation({ ...newConversation, title: e.target.value })}
                  placeholder="عنوان گفتگو را وارد کنید"
                />
              </div>

              {newConversation.type === "project" && (
                <div>
                  <Label>پروژه</Label>
                  <Select value={newConversation.projectId} onValueChange={(value) => setNewConversation({ ...newConversation, projectId: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="انتخاب پروژه" />
                    </SelectTrigger>
                    <SelectContent>
                      {projects.map((project) => (
                        <SelectItem key={project.id} value={project.id}>
                          {project.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <Button onClick={() => createConversationMutation.mutate(newConversation)} className="w-full">
                ایجاد گفتگو
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle className="text-lg">گفتگوها</CardTitle>
            <div className="relative mt-2">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="جستجو در گفتگوها..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10"
              />
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-[500px]">
              {conversations
                .filter((conv) => 
                  !searchQuery || 
                  conv.title?.toLowerCase().includes(searchQuery.toLowerCase())
                )
                .map((conversation) => (
                  <div
                    key={conversation.id}
                    onClick={() => setSelectedConversation(conversation.id)}
                    className={`p-4 border-b cursor-pointer hover:bg-accent transition-colors ${
                      selectedConversation === conversation.id ? "bg-accent" : ""
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        {getConversationIcon(conversation.type)}
                        <span className="font-medium">{conversation.title || "بدون عنوان"}</span>
                      </div>
                      <Badge variant="outline">{getConversationTypeLabel(conversation.type)}</Badge>
                    </div>
                    {conversation.updatedAt && (
                      <span className="text-xs text-muted-foreground">
                        {format(conversation.updatedAt, "yyyy/MM/dd HH:mm")}
                      </span>
                    )}
                  </div>
                ))}
            </ScrollArea>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          {selectedConversation ? (
            <>
              <CardHeader className="border-b">
                <CardTitle className="text-lg">
                  {conversations.find(c => c.id === selectedConversation)?.title || "گفتگو"}
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[400px] p-4">
                  {messages.map((message) => (
                    <div key={message.id} className="mb-4">
                      <div className="bg-accent rounded-lg p-3">
                        <p className="text-sm">{message.content}</p>
                        {message.files && message.files.length > 0 && (
                          <div className="mt-2 space-y-1">
                            {message.files.map((file: any) => (
                              <a
                                key={file.id}
                                href={file.path}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center gap-2 text-xs text-blue-600 hover:underline"
                              >
                                <Paperclip className="h-3 w-3" />
                                {file.originalName}
                              </a>
                            ))}
                          </div>
                        )}
                        <span className="text-xs text-muted-foreground mt-2 block">
                          {message.createdAt && format(message.createdAt, "yyyy/MM/dd HH:mm")}
                        </span>
                      </div>
                    </div>
                  ))}
                </ScrollArea>
                
                <div className="border-t p-4">
                  <div className="flex gap-2">
                    <Textarea
                      value={messageContent}
                      onChange={(e) => setMessageContent(e.target.value)}
                      placeholder="پیام خود را بنویسید..."
                      className="resize-none"
                      rows={2}
                      onKeyPress={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage();
                        }
                      }}
                    />
                    <div className="flex flex-col gap-2">
                      <label htmlFor="file-upload">
                        <Button type="button" variant="outline" size="icon" asChild>
                          <span>
                            <Paperclip className="h-4 w-4" />
                          </span>
                        </Button>
                        <input
                          id="file-upload"
                          type="file"
                          multiple
                          onChange={(e) => setSelectedFiles(e.target.files)}
                          className="hidden"
                        />
                      </label>
                      <Button onClick={handleSendMessage} size="icon">
                        <Send className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  {selectedFiles && selectedFiles.length > 0 && (
                    <div className="mt-2 text-sm text-muted-foreground">
                      {selectedFiles.length} فایل انتخاب شده
                    </div>
                  )}
                </div>
              </CardContent>
            </>
          ) : (
            <CardContent className="flex items-center justify-center h-[500px]">
              <div className="text-center text-muted-foreground">
                <MessageSquare className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p>یک گفتگو را انتخاب کنید</p>
              </div>
            </CardContent>
          )}
        </Card>
      </div>
    </div>
  );
}
