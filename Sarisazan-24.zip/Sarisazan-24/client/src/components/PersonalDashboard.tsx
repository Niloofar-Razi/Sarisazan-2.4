import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { toPersianDigits } from "@/lib/persian-utils";
import { CheckCircle2, Circle, Plus, Send, Calendar as CalendarIcon } from "lucide-react";
import type { Task, DailyNote, FollowUpTask } from "@shared/schema";
import { format } from "date-fns-jalali";

export default function PersonalDashboard() {
  const currentUser = JSON.parse(localStorage.getItem("user") || "{}");
  const userId = currentUser.id;

  // Greeting based on time
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "صبح بخیر";
    if (hour < 18) return "ظهر بخیر";
    return "عصر بخیر";
  };

  // Fetch tasks
  const { data: tasks = [], refetch: refetchTasks } = useQuery<Task[]>({
    queryKey: ["/api/tasks", userId],
    queryFn: async () => {
      const response = await fetch(`/api/tasks?userId=${userId}`);
      if (!response.ok) throw new Error("خطا در دریافت کارها");
      return response.json();
    },
    enabled: !!userId,
  });

  // Fetch daily notes
  const { data: dailyNotes = [], refetch: refetchNotes } = useQuery<DailyNote[]>({
    queryKey: ["/api/daily-notes", userId],
    queryFn: async () => {
      const response = await fetch(`/api/daily-notes?userId=${userId}`);
      if (!response.ok) throw new Error("خطا در دریافت یادداشت‌ها");
      return response.json();
    },
    enabled: !!userId,
  });

  // Fetch follow-up tasks sent TO me
  const { data: followUpTasksToMe = [], refetch: refetchFollowUps } = useQuery<FollowUpTask[]>({
    queryKey: ["/api/follow-up-tasks-to-me", userId],
    queryFn: async () => {
      const response = await fetch(`/api/follow-up-tasks?toUserId=${userId}`);
      if (!response.ok) throw new Error("خطا در دریافت پیگیری‌ها");
      return response.json();
    },
    enabled: !!userId,
  });

  // Fetch all users for follow-up dropdown
  const { data: users = [] } = useQuery({
    queryKey: ["/api/users"],
    queryFn: async () => {
      const response = await fetch("/api/users");
      if (!response.ok) throw new Error("خطا در دریافت کاربران");
      return response.json();
    },
  });

  const queryClient = useQueryClient();

  // Task mutations
  const addTaskMutation = useMutation({
    mutationFn: async (task: Partial<Task>) => {
      const response = await fetch("/api/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...task, userId }),
      });
      if (!response.ok) throw new Error("خطا در ایجاد کار");
      return response.json();
    },
    onSuccess: () => {
      refetchTasks();
    },
  });

  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<Task> }) => {
      const response = await fetch(`/api/tasks/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("خطا در به‌روزرسانی کار");
      return response.json();
    },
    onSuccess: () => {
      refetchTasks();
    },
  });

  // Daily note mutation
  const saveNoteMutation = useMutation({
    mutationFn: async (note: Partial<DailyNote>) => {
      const response = await fetch("/api/daily-notes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...note, userId }),
      });
      if (!response.ok) throw new Error("خطا در ذخیره یادداشت");
      return response.json();
    },
    onSuccess: () => {
      refetchNotes();
    },
  });

  // Follow-up task mutations
  const sendFollowUpMutation = useMutation({
    mutationFn: async (task: Partial<FollowUpTask>) => {
      const response = await fetch("/api/follow-up-tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...task, fromUserId: userId }),
      });
      if (!response.ok) throw new Error("خطا در ارسال پیگیری");
      return response.json();
    },
    onSuccess: () => {
      refetchFollowUps();
    },
  });

  const confirmFollowUpMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/follow-up-tasks/${id}/confirm`, {
        method: "PATCH",
      });
      if (!response.ok) throw new Error("خطا در تأیید پیگیری");
      return response.json();
    },
    onSuccess: () => {
      refetchFollowUps();
      refetchTasks();
    },
  });

  // State for forms
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newTaskCategory, setNewTaskCategory] = useState<"today" | "overdue" | "followup">("today");
  const [selectedDate, setSelectedDate] = useState("");
  const [noteContent, setNoteContent] = useState("");
  const [followUpTo, setFollowUpTo] = useState("");
  const [followUpTitle, setFollowUpTitle] = useState("");
  const [followUpDesc, setFollowUpDesc] = useState("");

  // Filter tasks
  const todayTasks = useMemo(() => tasks.filter(t => t.category === "today" && !t.isCompleted), [tasks]);
  const overdueTasks = useMemo(() => tasks.filter(t => t.category === "overdue" && !t.isCompleted), [tasks]);
  const followupTasks = useMemo(() => tasks.filter(t => t.category === "followup" && !t.isCompleted), [tasks]);
  const completedTasks = useMemo(() => tasks.filter(t => t.isCompleted), [tasks]);

  // Handle task completion
  const toggleTask = (task: Task) => {
    updateTaskMutation.mutate({
      id: task.id,
      data: {
        isCompleted: !task.isCompleted,
        completedAt: !task.isCompleted ? new Date() : null,
      },
    });
  };

  // Handle add task
  const handleAddTask = () => {
    if (!newTaskTitle.trim()) return;
    addTaskMutation.mutate({
      title: newTaskTitle,
      category: newTaskCategory,
      status: "pending",
    });
    setNewTaskTitle("");
  };

  // Calendar note handling
  const handleSaveNote = () => {
    if (!selectedDate || !noteContent.trim()) return;
    saveNoteMutation.mutate({
      noteDate: selectedDate,
      content: noteContent,
    });
    setNoteContent("");
    setSelectedDate("");
  };

  // Send follow-up task
  const handleSendFollowUp = () => {
    if (!followUpTo || !followUpTitle.trim()) return;
    sendFollowUpMutation.mutate({
      toUserId: followUpTo,
      title: followUpTitle,
      description: followUpDesc,
    });
    setFollowUpTo("");
    setFollowUpTitle("");
    setFollowUpDesc("");
  };

  const displayName = currentUser.firstName && currentUser.lastName
    ? `${currentUser.firstName} ${currentUser.lastName}`
    : currentUser.username || "کاربر";

  return (
    <div className="space-y-6">
      {/* Header with User Profile and Greeting */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">{displayName}</h1>
              <p className="text-muted-foreground">{getGreeting()}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tasks Sections */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Today's Tasks */}
        <Card>
          <CardHeader>
            <CardTitle>کارهای امروز من</CardTitle>
          </CardHeader>
          <Separator />
          <CardContent className="pt-4 space-y-3">
            {todayTasks.map((task) => (
              <div key={task.id} className="flex items-center gap-2">
                <Checkbox
                  checked={!!task.isCompleted}
                  onCheckedChange={() => toggleTask(task)}
                />
                <span className={task.isCompleted ? "line-through text-muted-foreground" : ""}>
                  {task.title}
                </span>
              </div>
            ))}
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm" className="w-full mt-2" onClick={() => setNewTaskCategory("today")}>
                  <Plus className="w-4 h-4 ml-2" />
                  افزودن کار جدید
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>کار جدید</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Input
                    placeholder="عنوان کار"
                    value={newTaskTitle}
                    onChange={(e) => setNewTaskTitle(e.target.value)}
                  />
                  <Button onClick={handleAddTask} className="w-full">
                    افزودن
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>

        {/* Overdue Tasks */}
        <Card>
          <CardHeader>
            <CardTitle>کارهای با تأخیر</CardTitle>
          </CardHeader>
          <Separator />
          <CardContent className="pt-4 space-y-3">
            {overdueTasks.map((task) => (
              <div key={task.id} className="flex items-center gap-2">
                <Checkbox
                  checked={!!task.isCompleted}
                  onCheckedChange={() => toggleTask(task)}
                />
                <span className={task.isCompleted ? "line-through text-muted-foreground" : "text-red-600"}>
                  {task.title}
                </span>
              </div>
            ))}
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm" className="w-full mt-2" onClick={() => setNewTaskCategory("overdue")}>
                  <Plus className="w-4 h-4 ml-2" />
                  افزودن کار با تأخیر
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>کار با تأخیر</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Input
                    placeholder="عنوان کار"
                    value={newTaskTitle}
                    onChange={(e) => setNewTaskTitle(e.target.value)}
                  />
                  <Button onClick={handleAddTask} className="w-full">
                    افزودن
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>

        {/* Follow-up Tasks */}
        <Card>
          <CardHeader>
            <CardTitle>کارهای قابل پیگیری</CardTitle>
          </CardHeader>
          <Separator />
          <CardContent className="pt-4 space-y-3">
            {followupTasks.map((task) => (
              <div key={task.id} className="flex items-center gap-2">
                <Checkbox
                  checked={!!task.isCompleted}
                  onCheckedChange={() => toggleTask(task)}
                />
                <span className={task.isCompleted ? "line-through text-muted-foreground" : ""}>
                  {task.title}
                </span>
              </div>
            ))}
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm" className="w-full mt-2" onClick={() => setNewTaskCategory("followup")}>
                  <Plus className="w-4 h-4 ml-2" />
                  افزودن کار قابل پیگیری
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>کار قابل پیگیری</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Input
                    placeholder="عنوان کار"
                    value={newTaskTitle}
                    onChange={(e) => setNewTaskTitle(e.target.value)}
                  />
                  <Button onClick={handleAddTask} className="w-full">
                    افزودن
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>
      </div>

      {/* Completed Tasks */}
      {completedTasks.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>انجام‌شده‌ها</CardTitle>
          </CardHeader>
          <Separator />
          <CardContent className="pt-4">
            <div className="space-y-2">
              {completedTasks.map((task) => (
                <div key={task.id} className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                  <span className="line-through text-muted-foreground">{task.title}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* My Duties */}
      <Card>
        <CardHeader>
          <CardTitle>وظایف من</CardTitle>
        </CardHeader>
        <Separator />
        <CardContent className="pt-4">
          <div className="space-y-4">
            {tasks.slice(0, 5).map((task) => (
              <div key={task.id} className="p-3 border rounded-lg">
                <div className="flex items-start gap-2">
                  <Checkbox
                    checked={!!task.isCompleted}
                    onCheckedChange={() => toggleTask(task)}
                    className="mt-1"
                  />
                  <div className="flex-1">
                    <h4 className="font-semibold">{task.title}</h4>
                    {task.description && (
                      <p className="text-sm text-muted-foreground mt-1">{task.description}</p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Persian Calendar with Notes */}
          <div className="mt-6">
            <h3 className="font-semibold mb-4">تقویم و یادداشت روزانه</h3>
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full">
                  <CalendarIcon className="w-4 h-4 ml-2" />
                  انتخاب تاریخ و ثبت یادداشت
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>یادداشت روزانه</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                  />
                  <Textarea
                    placeholder="یادداشت خود را وارد کنید..."
                    value={noteContent}
                    onChange={(e) => setNoteContent(e.target.value)}
                    rows={4}
                  />
                  <Button onClick={handleSaveNote} className="w-full">
                    ذخیره یادداشت
                  </Button>
                  
                  {/* Show existing notes */}
                  {dailyNotes.length > 0 && (
                    <div className="mt-4">
                      <h4 className="font-semibold mb-2">یادداشت‌های ذخیره شده</h4>
                      <div className="space-y-2 max-h-60 overflow-y-auto">
                        {dailyNotes.map((note) => (
                          <div key={note.id} className="p-2 border rounded">
                            <div className="text-sm text-muted-foreground">
                              {toPersianDigits(note.noteDate)}
                            </div>
                            <div>{note.content}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>

      {/* Follow-up from Others */}
      <Card>
        <CardHeader>
          <CardTitle>پیگیری از دیگران</CardTitle>
        </CardHeader>
        <Separator />
        <CardContent className="pt-4">
          <div className="space-y-4">
            {/* Tasks sent TO me */}
            {followUpTasksToMe.length > 0 && (
              <div>
                <h4 className="font-semibold mb-3">وظایف ارسال شده به من</h4>
                <div className="space-y-2">
                  {followUpTasksToMe.map((task: any) => (
                    <div key={task.id} className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between">
                        <div>
                          <h5 className="font-semibold">{task.title}</h5>
                          {task.description && (
                            <p className="text-sm text-muted-foreground">{task.description}</p>
                          )}
                        </div>
                        {!task.isConfirmed && (
                          <Button size="sm" onClick={() => confirmFollowUpMutation.mutate(task.id)}>
                            تأیید
                          </Button>
                        )}
                        {task.isConfirmed && (
                          <CheckCircle2 className="w-5 h-5 text-green-600" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Send task to someone */}
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full">
                  <Send className="w-4 h-4 ml-2" />
                  ارسال وظیفه به شخص دیگر
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>ارسال وظیفه</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Select value={followUpTo} onValueChange={setFollowUpTo}>
                    <SelectTrigger>
                      <SelectValue placeholder="انتخاب کاربر" />
                    </SelectTrigger>
                    <SelectContent>
                      {users.filter((u: any) => u.id !== userId).map((user: any) => (
                        <SelectItem key={user.id} value={user.id}>
                          {user.firstName && user.lastName
                            ? `${user.firstName} ${user.lastName}`
                            : user.username}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Input
                    placeholder="عنوان وظیفه"
                    value={followUpTitle}
                    onChange={(e) => setFollowUpTitle(e.target.value)}
                  />
                  <Textarea
                    placeholder="توضیحات (اختیاری)"
                    value={followUpDesc}
                    onChange={(e) => setFollowUpDesc(e.target.value)}
                    rows={3}
                  />
                  <Button onClick={handleSendFollowUp} className="w-full">
                    <Send className="w-4 h-4 ml-2" />
                    ارسال
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
