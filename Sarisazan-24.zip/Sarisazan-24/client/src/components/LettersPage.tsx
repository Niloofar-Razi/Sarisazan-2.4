import { PageHeader } from "./PageHeader";
import { Button } from "./ui/button";
import { Plus, Mail, Clock, CheckCircle2, FileText } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Inbox, Send, FolderOpen } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns-jalali";

interface Letter {
  id: string;
  fromUserId: string;
  subject: string;
  content: string;
  projectId?: string;
  createdAt: string;
  sender?: {
    id: string;
    firstName?: string;
    lastName?: string;
  };
  recipient?: {
    isRead: boolean;
    readAt?: string;
    receiptConfirmed: boolean;
  };
}

interface User {
  id: string;
  firstName?: string;
  lastName?: string;
  username: string;
}

interface Project {
  id: string;
  title: string;
}

export default function LettersPage() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [selectedLetter, setSelectedLetter] = useState<Letter | null>(null);
  const [inboxLetters, setInboxLetters] = useState<any[]>([]);
  const [outboxLetters, setOutboxLetters] = useState<Letter[]>([]);
  const [projectLetters, setProjectLetters] = useState<Letter[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [selectedProject, setSelectedProject] = useState<string>('');
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    subject: '',
    content: '',
    recipientIds: [] as string[],
    projectId: '',
  });

  const currentUser = JSON.parse(localStorage.getItem("user") || '{"id":"1"}');

  useEffect(() => {
    fetchInbox();
    fetchOutbox();
    fetchUsers();
    fetchProjects();
  }, []);

  const fetchInbox = async () => {
    try {
      const response = await fetch(`/api/letters/inbox/${currentUser.id}`);
      if (response.ok) {
        const data = await response.json();
        setInboxLetters(data);
      }
    } catch (error) {
      console.error('Error fetching inbox:', error);
    }
  };

  const fetchOutbox = async () => {
    try {
      const response = await fetch(`/api/letters/outbox/${currentUser.id}`);
      if (response.ok) {
        const data = await response.json();
        setOutboxLetters(data);
      }
    } catch (error) {
      console.error('Error fetching outbox:', error);
    }
  };

  const fetchProjectLetters = async (projectId: string) => {
    try {
      const response = await fetch(`/api/letters/project/${projectId}`);
      if (response.ok) {
        const data = await response.json();
        setProjectLetters(data);
      }
    } catch (error) {
      console.error('Error fetching project letters:', error);
    }
  };

  const fetchUsers = async () => {
    try {
      const response = await fetch('/api/users');
      if (response.ok) {
        const data = await response.json();
        setUsers(data);
      }
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  const fetchProjects = async () => {
    try {
      const response = await fetch('/api/projects');
      if (response.ok) {
        const data = await response.json();
        setProjects(data);
      }
    } catch (error) {
      console.error('Error fetching projects:', error);
    }
  };

  const handleCreateLetter = async () => {
    try {
      const formDataObj = new FormData();
      formDataObj.append('fromUserId', currentUser.id);
      formDataObj.append('recipientIds', JSON.stringify(formData.recipientIds));
      formDataObj.append('subject', formData.subject);
      formDataObj.append('content', formData.content);
      formDataObj.append('projectId', formData.projectId || '');

      selectedFiles.forEach((file) => {
        formDataObj.append('files', file);
      });

      const response = await fetch('/api/letters', {
        method: 'POST',
        body: formDataObj,
      });

      if (response.ok) {
        toast({
          title: "✅ نامه ارسال شد",
          description: "نامه با موفقیت ارسال شد",
        });
        resetForm();
        fetchOutbox();
      }
    } catch (error) {
      console.error('Error creating letter:', error);
      toast({
        title: "❌ خطا",
        description: "ارسال نامه با خطا مواجه شد",
        variant: "destructive",
      });
    }
  };

  const resetForm = () => {
    setFormData({
      subject: '',
      content: '',
      recipientIds: [],
      projectId: '',
    });
    setSelectedFiles([]);
    setDialogOpen(false);
  };

  const handleViewLetter = async (letter: any) => {
    setSelectedLetter(letter);
    setDetailsOpen(true);

    // Mark as read if in inbox
    if (letter.recipient && !letter.recipient.isRead) {
      try {
        await fetch(`/api/letters/${letter.letter.id}/read`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId: currentUser.id }),
        });
        fetchInbox();
      } catch (error) {
        console.error('Error marking as read:', error);
      }
    }
  };

  const handleConfirmReceipt = async (letterId: string) => {
    try {
      await fetch(`/api/letters/${letterId}/receipt`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id }),
      });
      toast({
        title: "✅ رسید تأیید شد",
        description: "دریافت نامه تأیید شد",
      });
      fetchInbox();
      setDetailsOpen(false);
    } catch (error) {
      console.error('Error confirming receipt:', error);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length + selectedFiles.length > 5) {
      toast({
        title: "⚠️ هشدار",
        description: "حداکثر 5 فایل می‌توانید پیوست کنید",
        variant: "destructive",
      });
      return;
    }
    setSelectedFiles([...selectedFiles, ...files]);
  };

  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title="نامه‌ها"
        subtitle="مدیریت نامه‌ها و پیام‌های اداری"
        theme="letters"
        actions={
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="w-4 h-4" />
                <span>نامه جدید</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>ایجاد نامه جدید</DialogTitle>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="subject">عنوان نامه *</Label>
                  <Input
                    id="subject"
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    placeholder="عنوان نامه را وارد کنید"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="content">متن نامه *</Label>
                  <Textarea
                    id="content"
                    value={formData.content}
                    onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                    placeholder="متن نامه را وارد کنید"
                    rows={6}
                  />
                </div>

                <div className="space-y-2">
                  <Label>گیرندگان نامه *</Label>
                  <div className="flex flex-wrap gap-2">
                    {users.map(user => (
                      <Badge
                        key={user.id}
                        variant={formData.recipientIds.includes(user.id) ? "default" : "outline"}
                        className="cursor-pointer"
                        onClick={() => {
                          if (formData.recipientIds.includes(user.id)) {
                            setFormData({
                              ...formData,
                              recipientIds: formData.recipientIds.filter(id => id !== user.id)
                            });
                          } else {
                            setFormData({
                              ...formData,
                              recipientIds: [...formData.recipientIds, user.id]
                            });
                          }
                        }}
                      >
                        {user.firstName && user.lastName 
                          ? `${user.firstName} ${user.lastName}`
                          : user.username}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="project">پروژه (اختیاری)</Label>
                  <Select
                    value={formData.projectId}
                    onValueChange={(value) => setFormData({ ...formData, projectId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="انتخاب پروژه" />
                    </SelectTrigger>
                    <SelectContent>
                      {projects.map(project => (
                        <SelectItem key={project.id} value={project.id}>
                          {project.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="files">پیوست فایل (حداکثر 5 فایل)</Label>
                  <Input
                    id="files"
                    type="file"
                    multiple
                    onChange={handleFileChange}
                  />
                  {selectedFiles.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {selectedFiles.map((file, index) => (
                        <Badge key={index} variant="outline" className="gap-1">
                          <FileText className="h-3 w-3" />
                          {file.name}
                          <button
                            onClick={() => setSelectedFiles(selectedFiles.filter((_, i) => i !== index))}
                            className="ml-1 hover:text-destructive"
                          >
                            ×
                          </button>
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>

                <div className="flex justify-end gap-2 pt-4">
                  <Button variant="outline" onClick={() => setDialogOpen(false)}>
                    لغو
                  </Button>
                  <Button 
                    onClick={handleCreateLetter} 
                    disabled={!formData.subject || !formData.content || formData.recipientIds.length === 0}
                  >
                    ارسال نامه
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="container mx-auto p-6">
        <Tabs defaultValue="inbox" className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-3">
            <TabsTrigger value="inbox" className="gap-2">
              <Inbox className="w-4 h-4" />
              صندوق ورودی
            </TabsTrigger>
            <TabsTrigger value="sent" className="gap-2">
              <Send className="w-4 h-4" />
              صندوق خروجی
            </TabsTrigger>
            <TabsTrigger value="project" className="gap-2">
              <FolderOpen className="w-4 h-4" />
              صندوق پروژه
            </TabsTrigger>
          </TabsList>

          <TabsContent value="inbox" className="mt-6">
            <div className="space-y-3">
              {inboxLetters.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  صندوق ورودی خالی است
                </p>
              ) : (
                inboxLetters.map((item) => (
                  <Card 
                    key={item.letter.id} 
                    className="p-4 hover:shadow-md transition-shadow cursor-pointer"
                    onClick={() => handleViewLetter(item)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-semibold">{item.letter.subject}</h3>
                        <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                          {item.letter.content}
                        </p>
                        <div className="flex items-center gap-2 mt-2">
                          <Badge variant="outline">
                            از: {item.sender?.firstName && item.sender?.lastName
                              ? `${item.sender.firstName} ${item.sender.lastName}`
                              : 'ناشناس'}
                          </Badge>
                          {!item.recipient.isRead && <Badge>جدید</Badge>}
                          {item.recipient.receiptConfirmed && (
                            <Badge variant="secondary" className="gap-1">
                              <CheckCircle2 className="w-3 h-3" />
                              رسید تأیید شده
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        <Clock className="w-3 h-3 inline mr-1" />
                        {format(new Date(item.letter.createdAt), 'yyyy/MM/dd HH:mm')}
                      </div>
                    </div>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="sent" className="mt-6">
            <div className="space-y-3">
              {outboxLetters.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  صندوق خروجی خالی است
                </p>
              ) : (
                outboxLetters.map((letter) => (
                  <Card key={letter.id} className="p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-semibold">{letter.subject}</h3>
                        <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                          {letter.content}
                        </p>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        <Clock className="w-3 h-3 inline mr-1" />
                        {format(new Date(letter.createdAt), 'yyyy/MM/dd HH:mm')}
                      </div>
                    </div>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="project" className="mt-6">
            <div className="space-y-4">
              <Select value={selectedProject} onValueChange={(value) => {
                setSelectedProject(value);
                fetchProjectLetters(value);
              }}>
                <SelectTrigger className="max-w-md">
                  <SelectValue placeholder="انتخاب پروژه" />
                </SelectTrigger>
                <SelectContent>
                  {projects.map(project => (
                    <SelectItem key={project.id} value={project.id}>
                      {project.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <div className="space-y-3">
                {selectedProject === '' ? (
                  <p className="text-center text-muted-foreground py-8">
                    ابتدا یک پروژه انتخاب کنید
                  </p>
                ) : projectLetters.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">
                    نامه‌ای برای این پروژه وجود ندارد
                  </p>
                ) : (
                  projectLetters.map((letter) => (
                    <Card key={letter.id} className="p-4 hover:shadow-md transition-shadow">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-semibold">{letter.subject}</h3>
                          <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                            {letter.content}
                          </p>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          <Clock className="w-3 h-3 inline mr-1" />
                          {format(new Date(letter.createdAt), 'yyyy/MM/dd HH:mm')}
                        </div>
                      </div>
                    </Card>
                  ))
                )}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Letter Details Dialog */}
      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{selectedLetter?.letter?.subject || selectedLetter?.subject}</DialogTitle>
          </DialogHeader>
          
          {selectedLetter && (
            <div className="space-y-4">
              <div className="bg-muted p-4 rounded-lg">
                <p className="whitespace-pre-wrap">{(selectedLetter as any).letter?.content || selectedLetter.content}</p>
              </div>

              {selectedLetter.sender && (
                <div className="flex items-center gap-2 text-sm">
                  <Mail className="w-4 h-4" />
                  <span>
                    از: {selectedLetter.sender.firstName && selectedLetter.sender.lastName
                      ? `${selectedLetter.sender.firstName} ${selectedLetter.sender.lastName}`
                      : 'ناشناس'}
                  </span>
                </div>
              )}

              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="w-4 h-4" />
                {format(new Date((selectedLetter as any).letter?.createdAt || selectedLetter.createdAt), 'yyyy/MM/dd - HH:mm')}
              </div>

              {(selectedLetter as any).recipient && !(selectedLetter as any).recipient.receiptConfirmed && (
                <div className="pt-4">
                  <Button 
                    onClick={() => handleConfirmReceipt((selectedLetter as any).letter.id)}
                    className="w-full"
                  >
                    <CheckCircle2 className="w-4 h-4 ml-2" />
                    تأیید دریافت نامه
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
