export function toPersianDigits(str: string | number): string {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return String(str).replace(/\d/g, (digit) => persianDigits[parseInt(digit)]);
}

export function toEnglishDigits(str: string): string {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return str.replace(/[۰-۹]/g, (digit) => String(persianDigits.indexOf(digit)));
}

export function formatCurrency(amount: string | number): string {
  const numStr = String(amount).replace(/,/g, '');
  const parts = numStr.split('.');
  const integerPart = parts[0];
  const decimalPart = parts[1];
  
  const withSeparator = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  
  const formatted = decimalPart ? `${withSeparator}.${decimalPart}` : withSeparator;
  return toPersianDigits(formatted);
}
