# سریع‌سازان البرز - سیستم مدیریت پروژه

## Overview
This project is a comprehensive construction project management application developed in Farsi. Its primary purpose is to streamline project tracking, material management, tendering processes, and internal communication for construction firms. Key capabilities include managing construction projects, tracking materials like bitumen, daily reporting, tender management with SLA alerts, an analytical dashboard, and an internal messaging system. The ambition is to provide a robust, localized solution for construction project management in Farsi-speaking markets, enhancing efficiency and communication.

## User Preferences
- All user interface elements and content should be in Farsi.
- The application should utilize the Jalali (Persian) calendar system for all date-related functionalities.
- The default currency for all financial transactions and displays should be Iranian Rial (ریال).
- The user interface design must support Right-to-Left (RTL) directionality consistently across all components.

## System Architecture

### UI/UX Decisions
- **Language & Direction**: Farsi language with RTL layout.
- **Date & Currency**: Jalali calendar and Iranian Rial.
- **Components**: Utilizes Radix UI and shadcn/ui for a modern and accessible design system.
- **Design Approach**: Focus on clear, intuitive navigation and data presentation.
- **AI Assistant**: Free token-based search with Persian-aware text normalization, punctuation handling, and stop words filtering, providing context-aware responses.

### Technical Implementations
- **Frontend**: React, Vite, TypeScript, Tailwind CSS, TanStack Query (React Query).
- **Backend**: Express.js, TypeScript.
- **Database**: PostgreSQL, managed with Drizzle ORM.
- **File Uploads**: `multer` for handling file attachments.
- **Performance**: Extensive use of `useMemo` for optimization.

### Feature Specifications
- **Project Management**: CRUD, progress tracking, search, filtering.
- **Material Management (Bitumen)**: Project-specific record management with CSV export.
- **Progress Statements**: Three-tab interface for Statements, Adjustments, and Bitumen Differences with CRUD, filtering, status tracking, financial calculation, soft delete, and negative amounts support.
- **Tender Management**: Comprehensive CRUD, automated SLA alerts, intelligent sorting, status tracking.
- **Alert Management**: Centralized listing, advanced filtering, manual creation, status changes, user assignment, CSV export. Automated hourly alerts for overdue tenders, nearing deadlines, and underperforming projects.
- **Lab Sheets Management**: CRUD, file attachment support, advanced filtering, status tracking, CSV export, soft delete.
- **Internal Messaging System**: Direct, Group, and Project-specific conversations with text, file attachments, read/unread status, search, and member management.
- **Reporting**: Daily activity and execution progress reports.
- **Roles & Permissions**: Role-based access control with predefined and custom roles, granular permissions, user profile management.
- **Dashboard**: Real database-driven KPIs, "هشدارها" tab for open alerts, and "تحلیل داده" tab with charts powered by Recharts.
- **Global Search**: Integrated search for project titles and contract numbers.
- **Task Management**: Comprehensive task list with project linking, assignee, attachments, reminders, confirmation workflow, completion tracking, priority levels.
- **Calendar**: Jalali calendar with daily note creation/editing and task reminder badges.
- **Sticky Notes**: Full-featured colorful notes system with checklist functionality.

### System Design Choices
- **Monorepo Structure**: Organized into `client/`, `server/`, and `shared/` directories.
- **Database Schema**: Comprehensive schema including `users`, `projects`, `bitumen_records`, `statements`, `tenders`, `alerts`, `tasks`, `calendar_notes`, `sticky_notes`, `letters`, and related tables.
- **Integrated Server**: Express server serves both API endpoints and frontend assets on port 5000.
- **Automated Tasks**: Scheduled tasks (e.g., hourly checks for alerts).

## External Dependencies
- **Database**: PostgreSQL.
- **ORM**: Drizzle ORM.
- **Node.js Driver**: `pg`.
- **Frontend Libraries**: React, Vite, TypeScript, Tailwind CSS, Radix UI, shadcn/ui, TanStack Query (React Query), Recharts.
- **Backend Libraries**: Express.js, TypeScript.
- **File Upload Middleware**: `multer`.

## Replit Setup (October 21, 2025)

### Fresh GitHub Import - Setup Completed
- **Import Date**: October 21, 2025
- **Source**: GitHub repository imported as ZIP file
- **Environment**: Successfully configured for Replit environment
- **Database**: PostgreSQL database already provisioned with DATABASE_URL environment variable
- **Schema**: Database schema pushed successfully using Drizzle Kit (`npm run db:push`)
- **Dependencies**: All npm packages installed successfully (494 packages)
- **Workflow**: Development server configured to run on port 5000 with `npm run dev`
- **Frontend Configuration**: Vite server properly configured with:
  - Host: `0.0.0.0` (required for Replit proxy)
  - Port: `5000`
  - `allowedHosts: true` (required for iframe preview)
  - HMR configured for WSS protocol with clientPort 443
- **Deployment**: Configured for autoscale deployment with:
  - Build: `npm run build`
  - Run: `npm run start`
- **Default Credentials**: Admin user created with username `admin` and password `admin123` (must be changed on first login)
- **Status**: Application running successfully with Persian RTL interface
- **Auto-Alert System**: Hourly scheduler configured and running
- **Permissions**: 34 permissions and 6 roles initialized automatically