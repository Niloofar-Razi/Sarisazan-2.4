import LoginForm from '../LoginForm';

export default function LoginFormExample() {
  return <LoginForm onLogin={(u, p) => console.log('Login:', u, p)} />;
}
