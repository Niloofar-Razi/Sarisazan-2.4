import UserCard from '../UserCard';

export default function UserCardExample() {
  return (
    <div className="p-4 max-w-md">
      <UserCard
        id="1"
        name="علی احمدی"
        role="مدیر پروژه"
        email="ali.ahmadi@example.com"
        phone="09123456789"
        location="تهران"
        isActive={true}
        onViewProfile={(id) => console.log('View profile:', id)}
      />
    </div>
  );
}
