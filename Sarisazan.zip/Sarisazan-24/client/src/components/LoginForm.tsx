import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { User, Lock, Eye, EyeOff } from "lucide-react";
import logoImage from "@assets/1_1759382492609.png";

export default function LoginForm({ onLogin }: { onLogin?: (username: string, password: string) => void }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Login attempt:", { username, password, rememberMe });
    onLogin?.(username, password);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardContent className="p-8 md:p-12">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="text-center space-y-4 mb-8">
              <div className="flex justify-center">
                <img 
                  src={logoImage} 
                  alt="سریع‌سازان البرز" 
                  className="w-32 h-auto mix-blend-multiply dark:mix-blend-lighten"
                  data-testid="img-logo"
                />
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold mb-2">سریع‌سازان البرز</h1>
                <p className="text-sm text-muted-foreground">سامانه مدیریت پروژه‌های ساخت</p>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="username" className="text-right block">نام کاربری</Label>
              <div className="relative">
                <Input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="نام کاربری خود را وارد کنید"
                  required
                  className="pr-10"
                  data-testid="input-username"
                  autoComplete="username"
                />
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-right block">رمز عبور</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="رمز عبور خود را وارد کنید"
                  required
                  className="pr-10 pl-10"
                  data-testid="input-password"
                  autoComplete="current-password"
                />
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  data-testid="button-toggle-password"
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <button
                type="button"
                className="text-sm text-primary hover:underline"
                onClick={() => console.log("Forgot password clicked")}
              >
                فراموشی رمز عبور؟
              </button>
              <div className="flex items-center gap-2">
                <Label htmlFor="remember" className="text-sm cursor-pointer">
                  مرا به خاطر بسپار
                </Label>
                <Checkbox
                  id="remember"
                  checked={rememberMe}
                  onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                  data-testid="checkbox-remember"
                />
              </div>
            </div>

            <Button type="submit" className="w-full" data-testid="button-login">
              ورود به سامانه
            </Button>

            <div className="text-center pt-4">
              <p className="text-xs text-muted-foreground">
                نسخه 1.0.0 | تمامی حقوق محفوظ است
              </p>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
