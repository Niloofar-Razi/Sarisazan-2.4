import { PageHeader } from "./PageHeader";
import { Button } from "./ui/button";
import { Plus, X, Check, Trash2 } from "lucide-react";
import { Card } from "./ui/card";
import { Checkbox } from "./ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

interface StickyNote {
  id: string;
  userId: string;
  title: string;
  content?: string;
  color: string;
  date?: string;
}

interface NoteItem {
  id: string;
  noteId: string;
  content: string;
  isCompleted: boolean;
  orderIndex: number;
}

const stickyColors = [
  { name: "زرد", value: "yellow", class: "bg-yellow-100 border-yellow-300 text-yellow-900" },
  { name: "سبز", value: "green", class: "bg-green-100 border-green-300 text-green-900" },
  { name: "آبی", value: "blue", class: "bg-blue-100 border-blue-300 text-blue-900" },
  { name: "صورتی", value: "pink", class: "bg-pink-100 border-pink-300 text-pink-900" },
  { name: "بنفش", value: "purple", class: "bg-purple-100 border-purple-300 text-purple-900" },
];

export default function NotesPage() {
  const [notes, setNotes] = useState<StickyNote[]>([]);
  const [noteItems, setNoteItems] = useState<Record<string, NoteItem[]>>({});
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newItem, setNewItem] = useState<Record<string, string>>({});
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    title: '',
    color: 'yellow',
    date: '',
  });

  const currentUser = JSON.parse(localStorage.getItem("user") || '{"id":"1"}');

  useEffect(() => {
    fetchNotes();
  }, []);

  const fetchNotes = async () => {
    try {
      const response = await fetch(`/api/sticky-notes?userId=${currentUser.id}`);
      if (response.ok) {
        const data = await response.json();
        setNotes(data);
        
        // Fetch items for each note
        for (const note of data) {
          fetchNoteItems(note.id);
        }
      }
    } catch (error) {
      console.error('Error fetching notes:', error);
    }
  };

  const fetchNoteItems = async (noteId: string) => {
    try {
      const response = await fetch(`/api/sticky-notes/${noteId}/items`);
      if (response.ok) {
        const data = await response.json();
        setNoteItems(prev => ({ ...prev, [noteId]: data }));
      }
    } catch (error) {
      console.error('Error fetching note items:', error);
    }
  };

  const handleCreateNote = async () => {
    try {
      const response = await fetch('/api/sticky-notes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          ...formData,
        }),
      });

      if (response.ok) {
        toast({
          title: "✅ یادداشت ایجاد شد",
          description: "یادداشت جدید با موفقیت ایجاد شد",
        });
        resetForm();
        fetchNotes();
      }
    } catch (error) {
      console.error('Error creating note:', error);
      toast({
        title: "❌ خطا",
        description: "ایجاد یادداشت با خطا مواجه شد",
        variant: "destructive",
      });
    }
  };

  const handleDeleteNote = async (noteId: string) => {
    try {
      const response = await fetch(`/api/sticky-notes/${noteId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        toast({
          title: "✅ یادداشت حذف شد",
          description: "یادداشت با موفقیت حذف شد",
        });
        fetchNotes();
      }
    } catch (error) {
      console.error('Error deleting note:', error);
    }
  };

  const handleAddItem = async (noteId: string) => {
    if (!newItem[noteId]?.trim()) return;

    try {
      const response = await fetch(`/api/sticky-notes/${noteId}/items`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: newItem[noteId],
          isCompleted: false,
          orderIndex: noteItems[noteId]?.length || 0,
        }),
      });

      if (response.ok) {
        setNewItem({ ...newItem, [noteId]: '' });
        fetchNoteItems(noteId);
      }
    } catch (error) {
      console.error('Error adding item:', error);
    }
  };

  const handleToggleItem = async (itemId: string, noteId: string, isCompleted: boolean) => {
    try {
      const response = await fetch(`/api/sticky-notes/items/${itemId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isCompleted: !isCompleted }),
      });

      if (response.ok) {
        fetchNoteItems(noteId);
      }
    } catch (error) {
      console.error('Error toggling item:', error);
    }
  };

  const handleDeleteItem = async (itemId: string, noteId: string) => {
    try {
      const response = await fetch(`/api/sticky-notes/items/${itemId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        fetchNoteItems(noteId);
      }
    } catch (error) {
      console.error('Error deleting item:', error);
    }
  };

  const resetForm = () => {
    setFormData({
      title: '',
      color: 'yellow',
      date: '',
    });
    setDialogOpen(false);
  };

  const getColorClass = (color: string) => {
    return stickyColors.find(c => c.value === color)?.class || stickyColors[0].class;
  };

  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title="یادداشت‌های من"
        subtitle="یادداشت‌های چسبان رنگی"
        theme="notes"
        actions={
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="w-4 h-4" />
                <span>یادداشت جدید</span>
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>ایجاد یادداشت جدید</DialogTitle>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="title">عنوان یادداشت *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="عنوان یادداشت را وارد کنید"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="color">رنگ یادداشت</Label>
                  <Select
                    value={formData.color}
                    onValueChange={(value) => setFormData({ ...formData, color: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {stickyColors.map(color => (
                        <SelectItem key={color.value} value={color.value}>
                          <div className="flex items-center gap-2">
                            <div className={`w-4 h-4 rounded ${color.class}`}></div>
                            {color.name}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="date">تاریخ (اختیاری)</Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  />
                </div>

                <div className="flex justify-end gap-2 pt-4">
                  <Button variant="outline" onClick={() => setDialogOpen(false)}>
                    لغو
                  </Button>
                  <Button onClick={handleCreateNote} disabled={!formData.title}>
                    ایجاد یادداشت
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="container mx-auto p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {notes.length === 0 ? (
            <div className="col-span-full text-center text-muted-foreground py-12">
              هنوز یادداشتی ایجاد نکرده‌اید
            </div>
          ) : (
            notes.map((note) => (
              <Card
                key={note.id}
                className={`p-4 border-2 ${getColorClass(note.color)} hover:shadow-lg transition-shadow relative`}
              >
                <button
                  onClick={() => handleDeleteNote(note.id)}
                  className="absolute top-2 left-2 p-1 hover:bg-black/10 rounded transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>

                <h3 className="font-bold text-lg mb-3 pr-6">{note.title}</h3>
                
                {note.date && (
                  <p className="text-xs mb-3 opacity-70">{note.date}</p>
                )}

                <div className="space-y-2">
                  {noteItems[note.id]?.map((item) => (
                    <div key={item.id} className="flex items-start gap-2 group">
                      <Checkbox
                        checked={item.isCompleted}
                        onCheckedChange={() => handleToggleItem(item.id, note.id, item.isCompleted)}
                        className="mt-0.5"
                      />
                      <span className={`text-sm flex-1 ${item.isCompleted ? 'line-through opacity-50' : ''}`}>
                        {item.content}
                      </span>
                      <button
                        onClick={() => handleDeleteItem(item.id, note.id)}
                        className="opacity-0 group-hover:opacity-100 transition-opacity p-0.5 hover:bg-black/10 rounded"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>

                <div className="mt-3 pt-3 border-t border-current/20">
                  <div className="flex gap-2">
                    <Input
                      value={newItem[note.id] || ''}
                      onChange={(e) => setNewItem({ ...newItem, [note.id]: e.target.value })}
                      placeholder="مورد جدید..."
                      className="text-sm bg-white/50"
                      onKeyPress={(e) => {
                        if (e.key === 'Enter') {
                          handleAddItem(note.id);
                        }
                      }}
                    />
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleAddItem(note.id)}
                      className="shrink-0"
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
