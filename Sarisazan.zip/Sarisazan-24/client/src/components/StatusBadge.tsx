import { Badge } from "@/components/ui/badge";

type Status = "active" | "completed" | "pending" | "suspended" | "approved" | "rejected";

const statusConfig: Record<Status, { label: string; variant: "default" | "secondary" | "outline" | "destructive" }> = {
  active: { label: "فعال", variant: "default" },
  completed: { label: "تکمیل شده", variant: "secondary" },
  pending: { label: "در انتظار", variant: "outline" },
  suspended: { label: "متوقف", variant: "destructive" },
  approved: { label: "تایید شده", variant: "default" },
  rejected: { label: "رد شده", variant: "destructive" },
};

export default function StatusBadge({ status }: { status: Status }) {
  const config = statusConfig[status];
  return <Badge variant={config.variant}>{config.label}</Badge>;
}
